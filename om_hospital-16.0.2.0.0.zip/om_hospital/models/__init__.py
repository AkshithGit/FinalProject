from . import patient
from . import doctor
from . import appointment
from . import sale
